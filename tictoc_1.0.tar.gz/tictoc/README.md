tictoc
======

R package with extended timing functions tic/toc, as well as stack and list structures.
