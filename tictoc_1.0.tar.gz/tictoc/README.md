tictoc
======

R package with extended timing functions tic/toc, as well as stack and list structures. See http://collectivemedia.github.io/tictoc/ for more detail.
